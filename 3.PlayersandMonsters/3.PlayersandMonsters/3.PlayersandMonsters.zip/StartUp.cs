﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var knight = new SoulMaster("GOshaka", 21);
        }
    }
}
