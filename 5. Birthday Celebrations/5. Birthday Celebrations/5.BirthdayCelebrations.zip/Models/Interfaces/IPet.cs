﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5._Birthday_Celebrations.Models.Interfaces
{
    public interface IPet
    {
        string Name { get; }
        string BithDate { get; }

    }
}
