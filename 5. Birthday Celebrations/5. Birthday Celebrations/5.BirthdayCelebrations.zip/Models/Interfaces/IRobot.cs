﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4._Border_Control.Models.Interfaces
{
    public interface IRobot
    {
        string Model { get; }
        string Id { get; }
    }
}
