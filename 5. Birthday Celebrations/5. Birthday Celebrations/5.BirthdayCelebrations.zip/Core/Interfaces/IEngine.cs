﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4._Border_Control.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
