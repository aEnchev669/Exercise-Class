﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4._Border_Control.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
